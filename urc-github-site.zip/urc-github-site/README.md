# USA Restore Co - GitHub Pages Website

This is a static website package ready for GitHub Pages.

## Files included

- `index.html` - homepage
- `services.html` - service overview page
- `contractors.html` - contractor application page
- `about.html` - brand overview page
- `contact.html` - customer lead form page
- `styles.css` - site styling
- `script.js` - mobile navigation toggle

## Before publishing live

Update these items:

1. Replace `info@usarestoreco.com` with your real business email.
2. Replace `https://formsubmit.co/your-email@example.com` in:
   - `contact.html`
   - `contractors.html`
3. If needed, update the phone number and company wording.
4. Add your logo images or favicon later if desired.

## How to publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload all files from this folder into the repository root.
3. Commit the files.
4. In GitHub, go to **Settings > Pages**.
5. Under **Build and deployment**, choose:
   - **Source:** Deploy from a branch
   - **Branch:** `main`
   - **Folder:** `/root`
6. Save.
7. GitHub will publish the site to your Pages URL.

## Custom domain setup

If you bought a domain from GoDaddy:

1. In GitHub Pages settings, add your custom domain.
2. In GoDaddy DNS, point the domain to GitHub Pages.
3. Add `www` with a CNAME record pointing to your GitHub Pages URL.
4. Wait for DNS propagation.
5. Turn on HTTPS in GitHub Pages once available.

## Notes

- This site is static and free to host on GitHub Pages.
- The included forms use FormSubmit as a no-backend option.
- You can later swap forms to Formspree, Netlify Forms, Basin, Tally, or a custom backend.
